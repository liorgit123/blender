// ui.js – Click-to-place UI + רינדור

function segmentText(text) {
  if (typeof Intl === "object" && Intl.Segmenter) {
    return Array.from(new Intl.Segmenter("he", { granularity: "grapheme" }).segment(text), s => s.segment);
  }
  return Array.from(text);
}

function renderQuestion(question) {
  const pattern = document.getElementById("pattern");
  const scrambleBox = document.getElementById("scramble");
  const categoryBox = document.getElementById("category");
  const factBox = document.getElementById("fact");
  const msgEl = document.getElementById("message");

  pattern.innerHTML = "";
  scrambleBox.innerHTML = "";
  categoryBox.textContent = "";
  factBox.textContent = "";
  msgEl.textContent = "";

  document.getElementById("hintBtn").disabled = false;

  const clean = question.answer.replace(/\s+/g, "");
  const letters = segmentText(clean);

  categoryBox.textContent = `קטגוריה: ${question.category}`;

  // hint 1: תיבות ריקות מופיעות כבר בהתחלה
  createSlots(question.answer, pattern);

  // אותיות מעורבבות ללחיצה
  const shuffled = shuffleArray(letters.slice());
  const rows = splitIntoRows(shuffled, 6);

  rows.forEach(rowLetters => {
    const row = document.createElement("div");
    row.className = "scramble-row";

    rowLetters.forEach(letter => {
      const tile = document.createElement("div");
      tile.className = "letter";
      tile.textContent = letter;
      tile.addEventListener("click", onLetterClick);
      row.appendChild(tile);
    });

    scrambleBox.appendChild(row);
  });
}

function splitIntoRows(items, maxPerRow) {
  const rowCount = Math.max(1, Math.ceil(items.length / maxPerRow));
  const baseCount = Math.floor(items.length / rowCount);
  const remainder = items.length % rowCount;
  const rows = [];
  let cursor = 0;

  for (let i = 0; i < rowCount; i++) {
    const count = baseCount + (i < remainder ? 1 : 0);
    rows.push(items.slice(cursor, cursor + count));
    cursor += count;
  }

  return rows;
}

function createSlots(answer, container) {
  const words = answer.split(" ");

  words.forEach((word, index) => {
    const line = document.createElement("div");
    line.className = "slot-line";

    const letters = segmentText(word);
    letters.forEach(() => {
      const slot = document.createElement("div");
      slot.className = "slot";
      slot.dataset.filled = "false";
      slot.addEventListener("click", onSlotClick);
      line.appendChild(slot);
    });

    container.appendChild(line);

    if (index < words.length - 1) {
      const gap = document.createElement("div");
      gap.className = "line-gap";
      container.appendChild(gap);
    }
  });
}

function onLetterClick(e) {
  const tile = e.currentTarget;
  const slots = [...document.querySelectorAll(".slot")].filter(
    s => s.dataset.filled === "false"
  );
  if (slots.length === 0) return;

  const letter = tile.textContent;
  const slot = slots[0];
  slot.textContent = letter;
  slot.dataset.filled = "true";

  tile.dataset.letter = letter;
  tile.textContent = "";
  tile.classList.add("empty");
  tile.removeEventListener("click", onLetterClick);
  tile.style.cursor = "default";
}

function onSlotClick(e) {
  const slot = e.currentTarget;
  if (slot.dataset.filled !== "true") return;

  const letter = slot.textContent;
  slot.textContent = "";
  slot.dataset.filled = "false";

  const tiles = [...document.querySelectorAll(".letter")].filter(
    t => t.dataset.letter === letter && t.classList.contains("empty")
  );
  if (tiles.length > 0) {
    const tile = tiles[0];
    tile.textContent = letter;
    tile.removeAttribute("data-letter");
    tile.classList.remove("empty");
    tile.addEventListener("click", onLetterClick);
    tile.style.cursor = "grab";
  }
}

function getUserAnswer() {
  const slots = [...document.querySelectorAll(".slot")].filter(
    s => !s.classList.contains("space")
  );
  return slots.map(s => s.textContent).join("");
}

function revealRandomLetter() {
  const slots = [...document.querySelectorAll(".slot")].filter(
    s => !s.classList.contains("space")
  );
  const clean = GameState.current.answer.replace(/\s+/g, "");
  const letters = segmentText(clean);

  const emptyIndices = slots
    .map((s, i) => (s.dataset.filled === "false" ? i : null))
    .filter(i => i !== null);

  if (emptyIndices.length === 0) return;

  const totalLetters = letters.length;
  const revealCount = Math.max(1, Math.ceil(totalLetters * 0.3));
  const indicesToReveal = shuffleArray(emptyIndices).slice(0, revealCount);

  indicesToReveal.forEach(idx => {
    const slot = slots[idx];
    slot.textContent = letters[idx];
    slot.dataset.filled = "true";

    const tiles = [...document.querySelectorAll(".letter")].filter(
      t => !t.classList.contains("empty") && t.textContent === letters[idx]
    );
    if (tiles.length > 0) {
      const tile = tiles[0];
      tile.dataset.letter = letters[idx];
      tile.textContent = "";
      tile.classList.add("empty");
      tile.removeEventListener("click", onLetterClick);
      tile.style.cursor = "default";
    }
  });
}

function revealAllLetters() {
  const slots = [...document.querySelectorAll(".slot")].filter(
    s => !s.classList.contains("space")
  );
  const clean = GameState.current.answer.replace(/\s+/g, "");
  const letters = segmentText(clean);

  slots.forEach((slot, i) => {
    slot.textContent = letters[i];
    slot.dataset.filled = "true";
  });

  const tiles = [...document.querySelectorAll(".letter")];
  tiles.forEach(t => {
    if (t.textContent) {
      t.dataset.letter = t.textContent;
      t.textContent = "";
    }
    t.classList.add("empty");
    t.removeEventListener("click", onLetterClick);
    t.style.cursor = "default";
  });
}

function shuffleArray(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
