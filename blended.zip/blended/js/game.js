// game.js – לוגיקת משחק בסיסית

const GameState = {
  questions: [],
  currentIndex: 0,
  current: null,
  hintLevel: 0
};

async function loadQuestions() {
  const res = await fetch("data/questions.json");
  if (!res.ok) {
    throw new Error("Failed to load questions.json");
  }
  const data = await res.json();
  GameState.questions = data;
}

function nextQuestion() {
  if (GameState.questions.length === 0) return;

  GameState.currentIndex =
    (GameState.currentIndex + 1) % GameState.questions.length;

  GameState.current = GameState.questions[GameState.currentIndex];
  GameState.hintLevel = 0;

  renderQuestion(GameState.current);
  resetButtons();
}

function resetButtons() {
  const hintBtn = document.getElementById("hintBtn");
  const checkBtn = document.getElementById("checkBtn");

  hintBtn.textContent = "רמז";
  hintBtn.disabled = false;
  checkBtn.disabled = false;
}

function checkAnswer() {
  const user = getUserAnswer();
  const target = GameState.current.answer.replace(/\s+/g, "");

  const msgEl = document.getElementById("message");

  if (!user || user.length !== target.length) {
    msgEl.textContent = "לא כל האותיות הונחו במקומן.";
    return;
  }

  if (user === target) {
    msgEl.textContent = "מעולה! תשובה נכונה.";
  } else {
    msgEl.textContent = "לא מדויק, נסה שוב.";
  }
}

function showHint() {
  GameState.hintLevel++;

  const factBox = document.getElementById("fact");
  const hintBtn = document.getElementById("hintBtn");
  const checkBtn = document.getElementById("checkBtn");

  if (GameState.hintLevel === 1) {
    factBox.textContent = `רמז: ${GameState.current.fact}`;
  } else if (GameState.hintLevel === 2) {
    revealRandomLetter();
    hintBtn.textContent = "גלה";
  } else if (GameState.hintLevel === 3) {
    revealAllLetters();
    hintBtn.disabled = true;
    checkBtn.disabled = true;
  }
}
